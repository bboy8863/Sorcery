#include "gameover.h"
using namespace std;
Gameover::Gameover(string name): name{name}{}

string Gameover::getName() {return name;}
