#ifndef GAMEOVER_H
#define GAMEOVER_H
#include <string>
class Gameover {
	std::string name;
	public:
	Gameover(std::string name);
	std::string getName();
};
#endif
