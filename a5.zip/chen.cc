//#include "ascii_graphics.h"
#include <iostream>
#include <string>
#include <vector>
#include "window.h"
#include "ascii_graphics.h"

using namespace std;

int main() {
	Xwindow w;
	w.drawString(1,1,"hello World");
	w.drawString(200,200,"hello World");
	string s;
	cin >> s;
}	


